package com.rivki.katalogfilm.ui.movie

import androidx.lifecycle.ViewModel
import com.rivki.katalogfilm.model.MovieModel
import com.rivki.katalogfilm.utils.DataDummy

class MovieViewModel : ViewModel() {
    fun getMovieList(): List<MovieModel> = DataDummy.generateDummyMovie()
}