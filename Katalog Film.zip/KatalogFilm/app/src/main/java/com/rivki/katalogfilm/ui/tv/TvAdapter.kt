package com.rivki.katalogfilm.ui.tv

import android.annotation.SuppressLint
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.rivki.katalogfilm.databinding.ItemViewContentBinding
import com.rivki.katalogfilm.model.TvModel
import com.rivki.katalogfilm.ui.detail.DetailActivity
import com.rivki.katalogfilm.utils.CommonUtils.showImage
import com.rivki.katalogfilm.utils.CommonUtils.substringText

class TvAdapter : RecyclerView.Adapter<TvAdapter.TvViewHolder>() {
    private val tvList = ArrayList<TvModel>()

    fun setTvs(tv: List<TvModel>?) {
        if (tv == null) return
        this.tvList.clear()
        this.tvList.addAll(tv)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TvAdapter.TvViewHolder {
        val itemViewContentBinding =
            ItemViewContentBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TvViewHolder(itemViewContentBinding)
    }

    override fun onBindViewHolder(holder: TvAdapter.TvViewHolder, position: Int) {
        holder.bind(tvList[position])
    }

    override fun getItemCount(): Int = tvList.size

    inner class TvViewHolder(private val binding: ItemViewContentBinding) :
        RecyclerView.ViewHolder(binding.root) {
        @SuppressLint("SetTextI18n")
        fun bind(tv: TvModel) {
            with(binding) {
                imageItem.showImage(tv.image)
                tvTitleItem.text = tv.name
                tvDateItem.text = tv.date
                tvDescItem.text = tv.description.substringText()
                rbItemView.rating = 4.toFloat()
                tvVoteDetail.text = "${tv.votes} votes"
                itemView.setOnClickListener {
                    val intent = Intent(itemView.context, DetailActivity::class.java)
                    intent.putExtra(DetailActivity.EXTRA_ID, tv.id.toString())
                    intent.putExtra(DetailActivity.IS_MOVIE, false)
                    itemView.context.startActivity(intent)
                }
            }
        }
    }
}