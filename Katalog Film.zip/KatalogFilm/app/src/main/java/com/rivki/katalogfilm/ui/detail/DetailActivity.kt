package com.rivki.katalogfilm.ui.detail

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.appbar.AppBarLayout
import com.rivki.katalogfilm.R
import com.rivki.katalogfilm.base.BaseActivity
import com.rivki.katalogfilm.databinding.ActivityDetailBinding
import com.rivki.katalogfilm.model.MovieModel
import com.rivki.katalogfilm.model.TvModel
import com.rivki.katalogfilm.utils.CommonUtils.showImage
import kotlinx.android.synthetic.main.item_view_content.*

class DetailActivity: BaseActivity() {
    companion object{
        const val EXTRA_ID = "extra_id"
        const val IS_MOVIE = "IS_MOVIE"
    }

    private lateinit var detailBinding: ActivityDetailBinding
    private lateinit var movie: MovieModel
    private lateinit var tv: TvModel

    override fun onSetupLayout(savedInstanceState: Bundle?) {
        setContentView(R.layout.activity_detail)
    }

    override fun onViewReady(savedInstanceState: Bundle?) {
        lateinit var title: String
        val viewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory())[DetailViewModel::class.java]
        val extras = intent.extras
        val isMovie = extras?.getBoolean(IS_MOVIE) ?: false
        val id = extras?.getString(EXTRA_ID)

        if (isMovie){
            with(viewModel){
                setSelectedMovie(id!!)
                movie = getMovie()
            }
            title = movie.name
        }else{
            with(viewModel){
                setSelectedTv(id!!)
                tv = getTv()
            }
            title = tv.name
        }
        detailBinding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(detailBinding.root)

        var isShow = true
        var scrollRange = -1
        with(detailBinding){
            setSupportActionBar(toolbarDetail)
            supportActionBar?.let {
                it.setDisplayHomeAsUpEnabled(true)
                it.setDisplayShowHomeEnabled(true)
            }
            ctDetail.title = " "
            appbarDetail.addOnOffsetChangedListener(AppBarLayout.OnOffsetChangedListener{appBarLayout, verticalOffset ->
                if (scrollRange == -1) scrollRange = appBarLayout?.totalScrollRange!!
                if(scrollRange + verticalOffset == 0){
                    ctDetail.title = title
                    ctDetail.setCollapsedTitleTextColor(ContextCompat.getColor(this@DetailActivity, R.color.white))
                    isShow = true
                }else if(isShow){
                    ctDetail.title = " "
                    isShow = false
                }
            })
        }
        showData(isMovie)
    }

    @SuppressLint("SetTextI18n")
    private fun showData(isMovie: Boolean){
        if(isMovie){
            with(detailBinding){
                Log.d("DATA_MOVIE", movie.description)
                imgDetail.showImage(movie.image)
                tvTitleDetail.text = movie.name
                tvDateDetail.text = movie.date
                tvDescDetail.text = movie.description
                tvVoteDetail.text = "${movie.votes} votes"
                rbDetail.rating = 4.toFloat()
            }
        }else{
            with(detailBinding){
                imgDetail.showImage(tv.image)
                tvTitleDetail.text = tv.name
                tvDateDetail.text = tv.date
                tvDescDetail.text = tv.description
                tvVoteDetail.text = "${tv.votes} votes"
                rbDetail.rating = 4.toFloat()
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.home -> {
                onBackPressed()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}