package com.rivki.katalogfilm.ui.tv

import androidx.lifecycle.ViewModel
import com.rivki.katalogfilm.model.TvModel
import com.rivki.katalogfilm.utils.DataDummy

class TvViewModel : ViewModel() {
    fun getDummyTvSeries(): List<TvModel> = DataDummy.generateDummyTv()
}