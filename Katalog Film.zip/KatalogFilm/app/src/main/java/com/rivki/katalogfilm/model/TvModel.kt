package com.rivki.katalogfilm.model

data class TvModel(
    val id: Int,
    val image: String,
    val name: String,
    val date: String,
    val votes: Int,
    val description: String
)