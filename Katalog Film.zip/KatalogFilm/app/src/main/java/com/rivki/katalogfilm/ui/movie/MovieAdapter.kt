package com.rivki.katalogfilm.ui.movie

import android.annotation.SuppressLint
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.rivki.katalogfilm.databinding.ItemViewContentBinding
import com.rivki.katalogfilm.model.MovieModel
import com.rivki.katalogfilm.ui.detail.DetailActivity
import com.rivki.katalogfilm.utils.CommonUtils.showImage
import com.rivki.katalogfilm.utils.CommonUtils.substringText

class MovieAdapter : RecyclerView.Adapter<MovieAdapter.MovieViewHolder>() {
    private val listMovie = ArrayList<MovieModel>()

    fun setMovie(movies: List<MovieModel>?) {
        if (movies == null) return
        this.listMovie.clear()
        this.listMovie.addAll(movies)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MovieAdapter.MovieViewHolder {
        val itemViewContentBinding =
            ItemViewContentBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MovieViewHolder(itemViewContentBinding)
    }

    override fun onBindViewHolder(holder: MovieAdapter.MovieViewHolder, position: Int) {
        val movie = listMovie[position]
        holder.bind(movie)
    }

    override fun getItemCount(): Int = listMovie.size

    inner class MovieViewHolder(private val binding: ItemViewContentBinding) :
        RecyclerView.ViewHolder(binding.root) {
        @SuppressLint("SetTextI18n")
        fun bind(movie: MovieModel) {
            with(binding) {
                imageItem.showImage(movie.image)
                tvTitleItem.text = movie.name
                tvDateItem.text = movie.date
                tvDescItem.text = movie.description.substringText()
                rbItemView.rating = 4.toFloat()
                tvVoteDetail.text = "${movie.votes} votes"
                itemView.setOnClickListener {
                    val intent = Intent(itemView.context, DetailActivity::class.java)
                    intent.putExtra(DetailActivity.EXTRA_ID, movie.id.toString())
                    intent.putExtra(DetailActivity.IS_MOVIE, true)
                    itemView.context.startActivity(intent)
                }
            }
        }
    }
}