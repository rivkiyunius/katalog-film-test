package com.rivki.katalogfilm.ui.detail

import androidx.lifecycle.ViewModel
import com.rivki.katalogfilm.model.MovieModel
import com.rivki.katalogfilm.model.TvModel
import com.rivki.katalogfilm.utils.DataDummy

class DetailViewModel : ViewModel() {
    private lateinit var movieId: String
    private lateinit var tvId: String

    fun setSelectedMovie(movieId: String) {
        this.movieId = movieId
    }

    fun setSelectedTv(tvId: String) {
        this.tvId = tvId
    }

    fun getMovie(): MovieModel =
        DataDummy.generateDummyMovie().find { it.id.toString() == movieId }!!

    fun getTv(): TvModel =
        DataDummy.generateDummyTv().find { it.id.toString() == tvId }!!
}