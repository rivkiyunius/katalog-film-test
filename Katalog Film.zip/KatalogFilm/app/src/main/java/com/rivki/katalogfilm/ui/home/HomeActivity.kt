package com.rivki.katalogfilm.ui.home

import android.os.Bundle
import com.rivki.katalogfilm.R
import com.rivki.katalogfilm.base.BaseActivity
import kotlinx.android.synthetic.main.activity_home.*

class HomeActivity : BaseActivity() {
    override fun onSetupLayout(savedInstanceState: Bundle?) {
        setContentView(R.layout.activity_home)
    }

    override fun onViewReady(savedInstanceState: Bundle?) {
        val tabsPagerAdapter = TabsPagerAdapter(this, supportFragmentManager)
        view_pager.adapter = tabsPagerAdapter
        tabs.setupWithViewPager(view_pager)
        supportActionBar?.elevation = 0f
    }
}