package com.rivki.katalogfilm.ui.detail

import com.rivki.katalogfilm.utils.DataDummy
import org.junit.Test

import org.junit.Assert.*
import org.junit.Before

class DetailViewModelTest {
    private lateinit var viewModel: DetailViewModel
    private val dummyMovie = DataDummy.generateDummyMovie()[0]
    private val dummyTv = DataDummy.generateDummyTv()[0]
    private val movieId = dummyMovie.id
    private val tvId = dummyTv.id

    @Before
    fun setup(){
        viewModel = DetailViewModel()
        viewModel.setSelectedMovie(movieId.toString())
        viewModel.setSelectedTv(tvId.toString())
    }

    @Test
    fun getMovie() {
        viewModel.setSelectedMovie(dummyMovie.id.toString())
        val movie = viewModel.getMovie()
        assertNotNull(movie)
        assertEquals(dummyMovie.id, movie.id)
        assertEquals(dummyMovie.name, movie.name)
    }

    @Test
    fun getTv() {
        viewModel.setSelectedTv(dummyTv.id.toString())
        val tv = viewModel.getTv()
        assertNotNull(tv)
        assertEquals(dummyTv.id, tv.id)
        assertEquals(dummyTv.name, tv.name)
    }
}