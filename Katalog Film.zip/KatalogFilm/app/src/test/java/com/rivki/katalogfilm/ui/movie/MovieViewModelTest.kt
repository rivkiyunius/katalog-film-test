package com.rivki.katalogfilm.ui.movie

import org.junit.Test

import org.junit.Assert.*
import org.junit.Before

class MovieViewModelTest {
    private lateinit var viewModel: MovieViewModel

    @Before
    fun init(){
        viewModel = MovieViewModel()
    }

    @Test
    fun getMovieList() {
        val movies = viewModel.getMovieList()
        assertNotNull(movies)
        assertEquals(10, movies.size)
    }
}