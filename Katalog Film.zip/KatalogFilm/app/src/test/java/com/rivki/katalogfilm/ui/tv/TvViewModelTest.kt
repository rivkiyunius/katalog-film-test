package com.rivki.katalogfilm.ui.tv

import org.junit.Test

import org.junit.Assert.*
import org.junit.Before

class TvViewModelTest {
    private lateinit var viewModel: TvViewModel

    @Before
    fun init(){
        viewModel = TvViewModel()
    }

    @Test
    fun getDummyTvSeries() {
        val tvs = viewModel.getDummyTvSeries()
        assertNotNull(tvs)
        assertEquals(10, tvs.size)
    }
}